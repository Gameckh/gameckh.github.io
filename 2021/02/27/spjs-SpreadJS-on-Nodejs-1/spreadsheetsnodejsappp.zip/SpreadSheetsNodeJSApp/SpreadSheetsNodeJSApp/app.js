var fs = require('fs');

// Initialize the mock browser variables
var mockBrowser = require('mock-browser').mocks.MockBrowser;
global.window = mockBrowser.createWindow();
global.document = window.document;
global.navigator = window.navigator;
global.HTMLCollection = window.HTMLCollection;
global.getComputedStyle = window.getComputedStyle;

var fileReader = require('filereader');
global.FileReader = fileReader;

var GC = require('@grapecity/spread-sheets');
var GCExcel = require('@grapecity/spread-excelio');

GC.Spread.Sheets.LicenseKey = GCExcel.LicenseKey = "<YOUR KEY HERE>";

var packageJson = require('./package.json');
console.log('\n** Using Spreadjs Version "' + packageJson.dependencies["@grapecity/spread-sheets"] + '" **');

var wb = new GC.Spread.Sheets.Workbook();

var excelIO = new GCExcel.IO();

// Instantiate the spreadsheet and modify it
console.log('\nManipulating Spreadsheet\n---');
try {
    var file = fs.readFileSync('./content/billingInvoiceTemplate.xlsx');
    excelIO.open(file.buffer, (data) => {
        wb.fromJSON(data);
        const readline = require('readline');
        
        var invoice = {
            generalInfo: [],
            invoiceItems: [],
            companyDetails: []
        };

        fillGeneralInformation();

        function fillGeneralInformation() {
            console.log("-----------------------\nFill in Invoice Details\n-----------------------")
            const rl = readline.createInterface({
                input: process.stdin,
                output: process.stdout
            });
            var generalInfoArray = [];
            rl.question('Invoice Number: ', (answer) => {
                generalInfoArray.push(answer);
                rl.question('Invoice Date (dd Month Year): ', (answer) => {
                    generalInfoArray.push(answer);
                    rl.question('Payment Due Date (dd Month Year): ', (answer) => {
                        generalInfoArray.push(answer);
                        rl.question('Customer Name: ', (answer) => {
                            generalInfoArray.push(answer);
                            rl.question('Customer Company Name: ', (answer) => {
                                generalInfoArray.push(answer);
                                rl.question('Customer Street Address: ', (answer) => {
                                    generalInfoArray.push(answer);
                                    rl.question('Customer City, State, Zip (<City>, <State Abbr> <Zip>): ', (answer) => {
                                        generalInfoArray.push(answer);
                                        rl.question('Invoice Company Name: ', (answer) => {
                                            generalInfoArray.push(answer);
                                            rl.question('Invoice Street Address: ', (answer) => {
                                                generalInfoArray.push(answer);
                                                rl.question('Invoice City, State, Zip (<City>, <State Abbr> <Zip>): ', (answer) => {
                                                    generalInfoArray.push(answer);
                                                    rl.close();

                                                    invoice.generalInfo.push({
                                                        "invoiceNumber": generalInfoArray[0],
                                                        "invoiceDate": generalInfoArray[1],
                                                        "paymentDueDate": generalInfoArray[2],
                                                        "customerName": generalInfoArray[3],
                                                        "customerCompanyName": generalInfoArray[4],
                                                        "customerStreetAddress": generalInfoArray[5],
                                                        "customerCityStateZip": generalInfoArray[6],
                                                        "invoiceCompanyName": generalInfoArray[7],
                                                        "invoiceStreetAddress": generalInfoArray[8],
                                                        "invoiceCityStateZip": generalInfoArray[9],
                                                    });
                                                    console.log("General Invoice Information Stored");
                                                    fillCompanyDetails();
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        }

        function fillCompanyDetails() {
            console.log("-----------------------\nFill in Company Details\n-----------------------")
            const rl = readline.createInterface({
                input: process.stdin,
                output: process.stdout
            });
            var companyDetailsArray = []
            rl.question('Your Name: ', (answer) => {
                companyDetailsArray.push(answer);
                rl.question('Company Name: ', (answer) => {
                    companyDetailsArray.push(answer);
                    rl.question('Address Line 1: ', (answer) => {
                        companyDetailsArray.push(answer);
                        rl.question('Address Line 2: ', (answer) => {
                            companyDetailsArray.push(answer);
                            rl.question('Address Line 3: ', (answer) => {
                                companyDetailsArray.push(answer);
                                rl.question('Address Line 4: ', (answer) => {
                                    companyDetailsArray.push(answer);
                                    rl.question('Address Line 5: ', (answer) => {
                                        companyDetailsArray.push(answer);
                                        rl.question('Phone: ', (answer) => {
                                            companyDetailsArray.push(answer);
                                            rl.question('Facsimile: ', (answer) => {
                                                companyDetailsArray.push(answer);
                                                rl.question('Website: ', (answer) => {
                                                    companyDetailsArray.push(answer);
                                                    rl.question('Email: ', (answer) => {
                                                        companyDetailsArray.push(answer);
                                                        rl.question('Currency Abbreviation: ', (answer) => {
                                                            companyDetailsArray.push(answer);
                                                            rl.question('Beneficiary: ', (answer) => {
                                                                companyDetailsArray.push(answer);
                                                                rl.question('Bank: ', (answer) => {
                                                                    companyDetailsArray.push(answer);
                                                                    rl.question('Bank Address: ', (answer) => {
                                                                        companyDetailsArray.push(answer);
                                                                        rl.question('Account Number: ', (answer) => {
                                                                            companyDetailsArray.push(answer);
                                                                            rl.question('Routing Number: ', (answer) => {
                                                                                companyDetailsArray.push(answer);
                                                                                rl.question('Make Checks Payable To: ', (answer) => {
                                                                                    companyDetailsArray.push(answer);
                                                                                    rl.close();

                                                                                    invoice.companyDetails.push({
                                                                                        "yourName": companyDetailsArray[0],
                                                                                        "companyName": companyDetailsArray[1],
                                                                                        "addressLine1": companyDetailsArray[2],
                                                                                        "addressLine2": companyDetailsArray[3],
                                                                                        "addressLine3": companyDetailsArray[4],
                                                                                        "addressLine4": companyDetailsArray[5],
                                                                                        "addressLine5": companyDetailsArray[6],
                                                                                        "phone": companyDetailsArray[7],
                                                                                        "facsimile": companyDetailsArray[8],
                                                                                        "website": companyDetailsArray[9],
                                                                                        "email": companyDetailsArray[10],
                                                                                        "currencyAbbreviation": companyDetailsArray[11],
                                                                                        "beneficiary": companyDetailsArray[12],
                                                                                        "bank": companyDetailsArray[13],
                                                                                        "bankAddress": companyDetailsArray[14],
                                                                                        "accountNumber": companyDetailsArray[15],
                                                                                        "routingNumber": companyDetailsArray[16],
                                                                                        "payableTo": companyDetailsArray[17]
                                                                                    });
                                                                                    console.log("Invoice Company Information Stored");

                                                                                    console.log("-----------------------\nFill in Invoice Items\n-----------------------")
                                                                                    fillInvoiceItemsInformation();
                                                                                });
                                                                            });
                                                                        });
                                                                    });
                                                                });
                                                            });
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        }

        function fillInvoiceItemsInformation() {
            const rl = readline.createInterface({
                input: process.stdin,
                output: process.stdout
            });
            var invoiceItemArray = [];
            rl.question('Add item?(y/n): ', (answer) => {
                switch (answer) {
                    case "y":
                        console.log("-----------------------\nEnter Item Information\n-----------------------");
                        rl.question('Quantity: ', (answer) => {
                            invoiceItemArray.push(answer);
                            rl.question('Details: ', (answer) => {
                                invoiceItemArray.push(answer);
                                rl.question('Unit Price: ', (answer) => {
                                    invoiceItemArray.push(answer);
                                    invoice.invoiceItems.push({
                                        "quantity": invoiceItemArray[0],
                                        "details": invoiceItemArray[1],
                                        "unitPrice": invoiceItemArray[2]
                                    });
                                    console.log("Item Information Added");
                                    rl.close();
                                    fillInvoiceItemsInformation(); 
                                });
                            });
                        });
                        break;
                    case "n":
                        rl.close();
                        return fillExcelFile();
                        break;
                    default:
                        console.log("Incorrect option, Please enter 'y' or 'n'.");
                }
            });
        }

        function fillExcelFile() {
            console.log("-----------------------\nFilling in Excel file\n-----------------------");

            fillBillingInfo();
            fillCompanySetup();
            fillInvoiceItems();

            exportExcelFile();
        }

        function fillBillingInfo() {
            var sheet = wb.getSheet(0);
            sheet.getCell(0, 2).value(invoice.generalInfo[0].invoiceNumber);
            sheet.getCell(1, 1).value(invoice.generalInfo[0].invoiceDate);
            sheet.getCell(2, 2).value(invoice.generalInfo[0].paymentDueDate);
            sheet.getCell(3, 1).value(invoice.generalInfo[0].customerName);
            sheet.getCell(4, 1).value(invoice.generalInfo[0].customerCompanyName);
            sheet.getCell(5, 1).value(invoice.generalInfo[0].customerStreetAddress);
            sheet.getCell(6, 1).value(invoice.generalInfo[0].customerCityStateZip);
            sheet.getCell(3, 3).value(invoice.generalInfo[0].invoiceCompanyName);
            sheet.getCell(4, 3).value(invoice.generalInfo[0].invoiceStreetAddress);
            sheet.getCell(5, 3).value(invoice.generalInfo[0].invoiceCityStateZip);
        }

        function fillCompanySetup() {
            var sheet = wb.getSheet(1);
            sheet.getCell(2, 2).value(invoice.companyDetails[0].yourName);
            sheet.getCell(3, 2).value(invoice.companyDetails[0].companyName);
            sheet.getCell(4, 2).value(invoice.companyDetails[0].addressLine1);
            sheet.getCell(5, 2).value(invoice.companyDetails[0].addressLine2);
            sheet.getCell(6, 2).value(invoice.companyDetails[0].addressLine3);
            sheet.getCell(7, 2).value(invoice.companyDetails[0].addressLine4);
            sheet.getCell(8, 2).value(invoice.companyDetails[0].addressLine5);
            sheet.getCell(9, 2).value(invoice.companyDetails[0].phone);
            sheet.getCell(10, 2).value(invoice.companyDetails[0].facsimile);
            sheet.getCell(11, 2).value(invoice.companyDetails[0].website);
            sheet.getCell(12, 2).value(invoice.companyDetails[0].email);
            sheet.getCell(13, 2).value(invoice.companyDetails[0].currencyAbbreviation);
            sheet.getCell(14, 2).value(invoice.companyDetails[0].beneficiary);
            sheet.getCell(15, 2).value(invoice.companyDetails[0].bank);
            sheet.getCell(16, 2).value(invoice.companyDetails[0].bankAddress);
            sheet.getCell(17, 2).value(invoice.companyDetails[0].accountNumber);
            sheet.getCell(18, 2).value(invoice.companyDetails[0].routingNumber);
            sheet.getCell(19, 2).value(invoice.companyDetails[0].payableTo);
        }

        function fillInvoiceItems() {
            var sheet = wb.getSheet(0);
            var rowsToAdd = 0;
            if (invoice.invoiceItems.length > 15) {
                rowsToAdd = invoice.invoiceItems.length - 15;
                sheet.addRows(22, rowsToAdd);
            }

            var rowIndex = 8;
            if (invoice.invoiceItems.length >= 1) {
                for (var i = 0; i < invoice.invoiceItems.length; i++) {
                    sheet.getCell(rowIndex, 1).value(invoice.invoiceItems[i].quantity);
                    sheet.getCell(rowIndex, 2).value(invoice.invoiceItems[i].details);
                    sheet.getCell(rowIndex, 3).value(invoice.invoiceItems[i].unitPrice);
                    rowIndex++;
                }
            }
        }

        function exportExcelFile() {
            excelIO.save(wb.toJSON(), (data) => {
                fs.appendFileSync('Invoice' + new Date().valueOf() + '.xlsx', new Buffer(data), function (err) {
                    console.log(err);
                });
                console.log("Export success");
            }, (err) => {
                console.log(err);
            }, { useArrayBuffer: true });
        }
    });

    

} catch (e) {
    console.error("** Error manipulating spreadsheet **");
    console.error(e);
}