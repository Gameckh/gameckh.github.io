package com.example.demo.websocket;

import org.springframework.web.socket.WebSocketSession;
import java.util.concurrent.ConcurrentHashMap;

/**
 * socket管理器
 */
public class SocketManager {
    private static ConcurrentHashMap<String, WebSocketSession> manager = new ConcurrentHashMap<String, WebSocketSession>();

    public static void add(String key, WebSocketSession webSocketSession) {
        System.out.println("新添加webSocket连接 {"+key+"} ");
        manager.put(key, webSocketSession);
    }

    public static void remove(String key) {
    	System.out.println("移除webSocket连接 {"+key+"} ");
        manager.remove(key);
    }

    public static WebSocketSession get(String key) {
    	System.out.println("获取webSocket连接 {"+key+"}");
        return manager.get(key);
    }
    
}