package com.example.demo.Controller;


import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.vo.FormDatasVO;

@RestController
@RequestMapping({"Spread","spread"})
public class SpreadController {



    @RequestMapping(value="/getReport", method= RequestMethod.POST)
    public String getReportDate(@RequestParam(value = "repaortName", required = true) String repaortName,
                                @RequestParam(value = "reportMonth", required = true) String reportMonth) {

        String content = getTextFileContent("reports/" + repaortName + '/' + reportMonth + ".ssjson");
        return content;
    }

    @RequestMapping(value="/getReportRange", method= RequestMethod.POST)
    public Object getReportDate(@RequestParam(value = "repaortName", required = true) String repaortName,
                                @RequestParam(value = "reportMonth", required = true) String reportMonth,
                                @RequestParam(value = "sheetName", required = true) String sheetName,
                                @RequestParam(value = "range", required = true) String range) {
        return getReportData(repaortName, reportMonth, sheetName, range);
    }
    
    @RequestMapping(value="/getReportRanges", method= RequestMethod.POST)
    public List<Object> getReportDatas(HttpServletRequest request,HttpServletResponse response, @RequestBody List<FormDatasVO> formDatas) {
    	List<Object> values = new ArrayList<>();
    	for(FormDatasVO formData : formDatas) {
    		values.add(getReportData(formData.getRepaortName(), formData.getReportMonth(), formData.getSheetName(), formData.getRange()));
    	}
        return values;
    }
    
    private Object getReportData(String repaortName, String reportMonth, String sheetName, String range) {
    	Object value = null;
        String content = getTextFileContent("reports/" + repaortName + '/' + reportMonth + ".ssjson");
        
        /*
         * Replace GcExcel to Fastjson.
         * */
        
        JSONObject workbook = JSON.parseObject(content);
        int sheetCount = workbook.getIntValue("sheetCount");
        if(sheetCount > 0) {
        	// parse range
        	// Range = {row: index, col: index, rowCount: num, colCount: num};
            JSONObject rangeJson = JSON.parseObject(range);
            String row = rangeJson.getString("row");
            String col = rangeJson.getString("col");
        	// sheets
        	JSONObject sheets = workbook.getJSONObject("sheets");
        	for(String key : sheets.keySet()) {
        		if(key.equals(sheetName)) {
        			// get sheet value
        			JSONObject sheet = sheets.getJSONObject(key);
        			JSONObject sheetData = sheet.getJSONObject("data");
        			if(sheetData != null) {
        				JSONObject dataTable = sheetData.getJSONObject("dataTable");
        				if(dataTable != null) {
        					JSONObject rowJson = dataTable.getJSONObject(row);
        					if(rowJson != null) {
            					JSONObject cellJson = rowJson.getJSONObject(col);
            					if(cellJson != null) {
                					value = cellJson.get("value");
            					}
        					}
        				}
        			}
        			break;
        		}
        	}
        }
        return value;
    }

    private String getTextFileContent(String path){
        try {
            File file = ResourceUtils.getFile(path);
            String encoding = "UTF-8";
            Long fileLength = file.length();
            byte[] fileContent = new byte[fileLength.intValue()];
            FileInputStream in = new FileInputStream(file);
            in.read(fileContent);
            in.close();
            String content = new String(fileContent, encoding);
            return content;
        }
        catch (Exception e){

        }
        return "";
    }

}
