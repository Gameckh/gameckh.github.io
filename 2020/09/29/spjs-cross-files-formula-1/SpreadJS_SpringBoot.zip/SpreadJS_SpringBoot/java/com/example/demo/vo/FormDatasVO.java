package com.example.demo.vo;

import java.io.Serializable;

public class FormDatasVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -50199178577710138L;

	String repaortName;
	
	String reportMonth;
	
	String sheetName;
	
	String range;

	public String getRepaortName() {
		return repaortName;
	}

	public void setRepaortName(String repaortName) {
		this.repaortName = repaortName;
	}

	public String getReportMonth() {
		return reportMonth;
	}

	public void setReportMonth(String reportMonth) {
		this.reportMonth = reportMonth;
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public String getRange() {
		return range;
	}

	public void setRange(String range) {
		this.range = range;
	}
	
}
