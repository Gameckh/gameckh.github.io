

GC.Spread.Common.CultureManager.culture("zh-cn");

var repaortName, reportMonth;

/** 
	声明一个自定义单元格类型，用于实现“打砖”功能
	a=>b
	var referJson = {loadFile:a, referFile:b}
	var ssjson = spread.toJSON();
	ssjson.referJson = referJson;
	$.ajax(ssjson);
	---------------------------------------------
	spread.fromJSON(ssjson)
	var referJson = ssjson.referJson;
*/
function CustomValidateCell(hostMargin) {
	this.typeName = "CustomValidateCell";
    this.hostMargin = hostMargin;
	this.margin = 0;
	this.color = 'red';
	this.size = 20;
	this.sideLength = 500;
	this.eq = "lib/eq.png";
	this.neq = "lib/neq.png";
	this.unknown = "lib/unknown.png";
	this.backgroundImage = this.unknown;
}
CustomValidateCell.prototype = new GC.Spread.Sheets.CellTypes.Text();
CustomValidateCell.prototype.paint = function (ctx, value, x, y, w, h, style, options) {
    style.hAlign = GC.Spread.Sheets.HorizontalAlign.left;
    GC.Spread.Sheets.CellTypes.Text.prototype.paint.call(this, ctx, value, x, y, w, h, style, options);
        
    if (!ctx) {
        return;
    }
    var tag = options.sheet.getTag(options.row, options.col, options.sheetArea);
    var startX = x + w - this.size - this.margin;
    var startY = y + (h - this.size) / 2 - this.margin;
    style.backgroundImage = this.backgroundImage;
    GC.Spread.Sheets.CellTypes.Text.prototype.paint.call(this, ctx, "", startX, startY, this.size, this.size, style, options);
};
CustomValidateCell.prototype.getHitInfo = function (x, y, cellStyle, cellRect, context) {
    var info = {
        x: x,
        y: y,
        row: context.row,
        col: context.col,
        cellStyle: cellStyle,
        cellRect: cellRect,
        sheetArea: context.sheetArea
    };
    var hitX = x;
    var hitY = y;
    x = cellRect.x;
    y = cellRect.y;
    var w = cellRect.width;
    var h = cellRect.height;

    var startX = x + w - this.size + this.margin;
    var startY = y + (h - this.size) / 2 + this.margin;
    var endX = x + w - this.margin;
    var endY = y + (h + this.size) / 2 - this.margin;
    // 这里判断逻辑参考paint中绘制的逻辑
    if (hitX > startX && hitX < endX && hitY > startY && hitY < endY) {
        info.isReservedLocation = true;
    }
    return info;
};
CustomValidateCell.prototype.processMouseEnter = function (hitInfo) {
    var sheet = hitInfo.sheet;
    if (sheet && hitInfo.isReservedLocation) {
        if (!this._toolTipElement) {
            var div = document.createElement("div");
            $(div).css("position", "absolute")
                .css("border", "1px #C0C0C0 solid")
                .css("box-shadow", "1px 2px 5px rgba(0,0,0,0.4)")
                .css("font", "9pt Arial")
                .css("background", "white")
                .css("padding", 5)
				.attr("class","toolTipElement");

            this._toolTipElement = div;
        }
        validateCellForCustomerCell(hitInfo.row, hitInfo.col, this);
        $(this._toolTipElement).html($('#validateCellInfo').html())
            .css("top", hitInfo.y + this.hostMargin.y + 15)
            .css("left", hitInfo.x + this.hostMargin.x + 15);
        $(this._toolTipElement).hide();
        document.body.insertBefore(this._toolTipElement, null);
        $(this._toolTipElement).show("fast");
        return true;
    } else {
        if (this._toolTipElement) {
            $(".toolTipElement").remove();
            this._toolTipElement = null;
            return true;
        }
    }
    return false;
};
CustomValidateCell.prototype.processMouseLeave = function (hitInfo) {
    var sheet = hitInfo.sheet;
	$(".toolTipElement").remove();
    this._toolTipElement = null;
    return false;
};
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

window.onload = function () {
    var spread = new GC.Spread.Sheets.Workbook(document.getElementById('ss'), {
        sheetCount: 1
    });
    var sheet = spread.getActiveSheet();

    var arr1 = [];
    var arr2 = [];
    sheet.bind(GC.Spread.Sheets.Events.CellChanged, function (e, info) {
        if(info.sheetArea === GC.Spread.Sheets.SheetArea.viewport){
//        console.log(sheet.getValue(info.row,info.col));
        arr1.push(sheet.getValue(info.row,info.col))
//            alert("Cell index (" + info.row + "," + info.col + ")");
        arr2.push(GC.Spread.Sheets.CalcEngine.rangeToFormula(new GC.Spread.Sheets.Range(info.row, info.col, 1,1), 0, 0, GC.Spread.Sheets.CalcEngine.RangeReferenceRelative.allRelative))
//        console.log(GC.Spread.Sheets.CalcEngine.rangeToFormula(new GC.Spread.Sheets.Range(info.row, info.col, 1,1), 0, 0, GC.Spread.Sheets.CalcEngine.RangeReferenceRelative.allRelative));
        console.log(arr2);
        //document.getElementById('p01').innerHTML = arr2[0];
        //document.getElementById('p02').innerHTML = arr2[2];
        //document.getElementById('p03').innerHTML = arr2[4];
        document.getElementById('p1').innerHTML = arr1[0];
        document.getElementById('p2').innerHTML = arr1[2];
        document.getElementById('p3').innerHTML = arr1[4];
        }
    });

    var ssDetail = new GC.Spread.Sheets.Workbook(document.getElementById('ssDetail'), {
        sheetCount: 1
    });
	$('#workbookRelateList').on('hidden.bs.modal', function () {
		$("#relateList").empty();
	})
}

function loadWorkbookDetail(category, subCategory) {
    repaortName = category, reportMonth = subCategory;
    $("#ssDetail").hide()
    $("#loadingInfo").show();

    $("#workbookListModal").modal('hide')
    $("#workbookDetailModal").modal('show')

    $.post("spread/getReport", { repaortName: repaortName, reportMonth: reportMonth }, function (data) {
        if (data != "0") {
            var json = JSON.parse(data);
            var ssDetail = GC.Spread.Sheets.findControl(document.getElementById('ssDetail'));
            ssDetail.fromJSON(json);

            $("#loadingInfo").hide();
            $("#ssDetail").show()
            setTimeout(() => {
                ssDetail.refresh();
            }, 300);
        }
    })

}

function selectWorkbookCell() {
    $("#workbookDetailModal").modal('hide')
    var ssDetail = GC.Spread.Sheets.findControl(document.getElementById('ssDetail'));
    var sheet = ssDetail.getActiveSheet();
    var cellRange = new GC.Spread.Sheets.Range(sheet.getActiveRowIndex(), sheet.getActiveColumnIndex(), 1, 1)
    var rangeInfo = GC.Spread.Sheets.CalcEngine.rangeToFormula(cellRange, 0, 0, GC.Spread.Sheets.CalcEngine.RangeReferenceRelative.allRelative, false)

    setCrossWorkbookFormula(sheet.name(), rangeInfo)

}

function deleteBricks(){
	var spread = GC.Spread.Sheets.findControl(document.getElementById('ss'));
	var sheet = spread.getActiveSheet();
	var sels = sheet.getSelections();
	var text = new GC.Spread.Sheets.CellTypes.Text();
	sheet.suspendPaint();
	sels.forEach(function(r){
		for(let i=r.row; i<r.row+r.rowCount; i++){
			for(let j=r.col; j<r.col+r.colCount; j++){
				sheet.setCellType(i,j,text);
				var cellRange = new GC.Spread.Sheets.Range(sheet.getActiveRowIndex(), sheet.getActiveColumnIndex(), 1, 1)
    			var cellFormula = GC.Spread.Sheets.CalcEngine.rangeToFormula(cellRange, 0, 0, GC.Spread.Sheets.CalcEngine.RangeReferenceRelative.allRelative, false)
				var name = 'CellValidate' + cellFormula;
				sheet.removeCustomName(name);
			}
		}
	});
	sheet.resumePaint();
}

function setCrossWorkbookFormula(sheetName, rangeInfo) {

    var spread = GC.Spread.Sheets.findControl(document.getElementById('ss'));
    var sheet = spread.getActiveSheet();
    var cellRange = new GC.Spread.Sheets.Range(sheet.getActiveRowIndex(), sheet.getActiveColumnIndex(), 1, 1)
    var cellFormula = GC.Spread.Sheets.CalcEngine.rangeToFormula(cellRange, 0, 0, GC.Spread.Sheets.CalcEngine.RangeReferenceRelative.allRelative, false)

    var name = 'CellValidate' + cellFormula
    if(sheet.getCustomName(name)){
        var result = confirm("验证已存在，是否替换？");
        if(result){
            sheet.removeCustomName(name);
        }
        else{
            return;
        }
    }

    var comment = [repaortName,reportMonth,sheetName,rangeInfo].join(',');
    sheet.addCustomName(name, cellFormula, 0, 0, comment);

    var hostDiv = document.getElementById('ss');
	var brickCellType = new CustomValidateCell({x: hostDiv.offsetLeft, y: hostDiv.offsetTop});
	var row = sheet.getActiveRowIndex(), col = sheet.getActiveColumnIndex();
	validateCellForCustomerCell(row, col, brickCellType);
    sheet.setCellType(row, col, brickCellType);
    sheet.repaint();
    console.log(sheet.getCustomName(name).getName());
}

function validateCellForCustomerCell(row, col, cell){

    var spread = GC.Spread.Sheets.findControl(document.getElementById('ss'));
    var sheet = spread.getActiveSheet();
    var cellRange = new GC.Spread.Sheets.Range(row, col, 1, 1)
    var cellFormula = GC.Spread.Sheets.CalcEngine.rangeToFormula(cellRange, 0, 0, GC.Spread.Sheets.CalcEngine.RangeReferenceRelative.allRelative, false)

    var name = 'CellValidate' + cellFormula;
    var customName = sheet.getCustomName(name);
    if(!customName){
        return;
    }

    var comment = customName.getComment();
    var data = comment.split(',')
	var range = GC.Spread.Sheets.CalcEngine.formulaToRanges(sheet, data[3], 0, 0);
    var formData = {
        repaortName: data[0],
        reportMonth: data[1],
        sheetName: data[2],
        range: JSON.stringify(range[0].ranges[0])
    }
	
	$.ajaxSettings.async = false;
    $.post("spread/getReportRange", formData, function (data) {
        if (data != undefined && data != null) {
			
			var val = sheet.getValue(row, col);
            document.getElementById('p0').innerHTML = cellFormula;
            document.getElementById('p1').innerHTML = val;
            document.getElementById('p2').innerHTML = comment;
            document.getElementById('p3').innerHTML = data;
			if(val == data){
				cell.backgroundImage = cell.eq;
			}else{
				cell.backgroundImage = cell.neq;
			}
        }
        else{
            console.log("获取失败")
			cell.backgroundImage = cell.unknown;
        }
    })
	$.ajaxSettings.async = true;

    return true;
}

function synchronizeData(){
	var spread = GC.Spread.Sheets.findControl(document.getElementById('ss'));
	var sheet = spread.getActiveSheet();
	var sels = sheet.getSelections();
	if(sels.length > 0){
		validateCell(sels[0]);
	}
}

function validateCell(range){

    var spread = GC.Spread.Sheets.findControl(document.getElementById('ss'));
	var formDatas = [];
	$("#allBricksTable").empty();
	if(range){
		var sheet = spread.getActiveSheet();
		bricksFormDatas(sheet, range.row, range.col, range.rowCount, range.colCount, formDatas);
	}else{
		for(let i=0; i<spread.getSheetCount(); i++){
			var sheet = spread.getSheet(i);
			var rowCount = sheet.getRowCount(),
				colCount = sheet.getColumnCount();
			bricksFormDatas(sheet, 0, 0, rowCount, colCount, formDatas)
		}
	}
	if(formDatas.length == 0){
		alert("没有发现打砖单元格");
		return;
	}
	
	$.ajax({
		type: 'POST',
		url: "spread/getReportRanges",
		data: JSON.stringify(formDatas),
		contentType: "application/json; charset=utf-8",
		dataType: "json",
		success: function(data){
			if (data != undefined && data != null) {
				if(range){
					var sheet = spread.getActiveSheet();
					sheet.suspendPaint();
					formDatas.forEach(function(fd,i){
						fd.data = data[i];
						var cellRange = fd.cellRange;
						sheet.setValue(cellRange.row, cellRange.col, fd.data);
					});
					sheet.resumePaint();
				}else{
					formDatas.forEach(function(fd,i){
						fd.data = data[i];
						createBricksList(fd,i);
					});
		            $('#allBricksList').modal('show');
				}
	        }
	        else{
	            alert("获取失败")
	        }
		}
	})
}

	function bricksFormDatas(sheet, row, col, rowCount, colCount, formDatas){
		for(let r=row; r<rowCount+row; r++){
			for(let c=col; c<colCount+col; c++){
				var ct = sheet.getCellType(r, c);
				if(ct instanceof CustomValidateCell){
				    var cellRange = new GC.Spread.Sheets.Range(r, c, 1, 1)
				    var cellFormula = GC.Spread.Sheets.CalcEngine.rangeToFormula(cellRange, 0, 0, GC.Spread.Sheets.CalcEngine.RangeReferenceRelative.allRelative, false)
				    var name = 'CellValidate' + cellFormula;
				    var customName = sheet.getCustomName(name);
				    if(!customName){
				        continue;
				    }
				    var comment = customName.getComment();
				    var data = comment.split(',')
					var range = GC.Spread.Sheets.CalcEngine.formulaToRanges(sheet, data[3], 0, 0);
				    var formData = {
				        repaortName: data[0],
						recentVal: sheet.getValue(r,c),
				        reportMonth: data[1],
				        sheetName: data[2],
						cellRange: cellRange,
				        cellFormula: cellFormula,
						comment: comment,
				        range: JSON.stringify(range[0].ranges[0])
						//range: range[0].ranges[0]
				   	}
					formDatas.push(formData);
				}
			}
		}
	}

	//T 创建列表
	function createBricksList(item,i){
		var sheetName = item.sheetName;
		var cellFormula = item.cellFormula;
		var comment = item.comment;
		var recentVal = item.recentVal;
		var data = item.data;
		var tr = '<tr class="brickCell" data-sheetName="'+sheetName+'"></tr>';
		var th = '<th scope="row">'+(i+1)+'</th>';
		var cellFormulaTd = '<td>'+cellFormula+'</td>';
		var recentValTd = '<td>'+recentVal+'</td>';
		var commentTd = '<td>'+comment+'</td>';
		var dataTd = '<td>'+data+'</td>';
		var trDom = $(tr);
		trDom.append(th);
		trDom.append(cellFormulaTd);
		trDom.append(recentValTd);
		trDom.append(commentTd);
		trDom.append(dataTd);
		$("#allBricksTable").append(trDom);
	}

var CrossWorkbookFormula = function () {
	this.typeName = "CrossWorkbookFormula";
};
CrossWorkbookFormula.prototype = new GC.Spread.CalcEngine.Functions.AsyncFunction("CROSSWORKBOOK", 4, 4, 
{
    description: "跨表格取数公式", 
    parameters: [{
        name: "repaortName",
        repeatable: false,
        optional: false
    },
    {
        name: "reportMonth",
        repeatable: false,
        optional: false
    },
    {
        name: "sheetName",
        repeatable: false,
        optional: false
    },
    {
        name: "range",
        repeatable: false,
        optional: false
    }]
});
//CrossWorkbookFormula.prototype.defaultValue = function () { return '取数中...'; };
CrossWorkbookFormula.prototype.defaultValue = function () { };

var arr=[];
CrossWorkbookFormula.prototype.evaluate = function (context, repaortName, reportMonth, sheetName, range) {
    var formData = {
        repaortName: repaortName,
        reportMonth: reportMonth,
        sheetName: sheetName,
        range: range
    }
//    document.getElementById('p33').innerHTML = range;

    $.post("spread/getReportRange", formData, function (data) {
        if (data != undefined && data != null) {
//            context.setAsyncResult(data);
//            console.log(data);
            arr.push(data);

            document.getElementById('p11').innerHTML = arr[0];
            document.getElementById('p22').innerHTML = arr[1];
            document.getElementById('p33').innerHTML = arr[2];
            console.log(arr);
        }
        else{
            context.setAsyncResult("Error");
        }
    })
};
GC.Spread.CalcEngine.Functions.defineGlobalCustomFunction("CROSSWORKBOOK", new CrossWorkbookFormula());