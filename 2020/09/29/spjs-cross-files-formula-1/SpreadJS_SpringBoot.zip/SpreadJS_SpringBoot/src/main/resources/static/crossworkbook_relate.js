var formulaCache = [];
var loadedFile = null;
var relations = [];

/*
$(document).ready(function () {
	new GC.Spread.Sheets.Workbook(document.getElementById('ss'), { sheetCount: 1 });
	$('#workbookRelateList').on('hidden.bs.modal', function () {
		$("#relateList").empty();
	})
});
*/

/*****************WebSocket*********************/

var stompClient = null;
var host="http://localhost:8080";

function setConnected(connected) {
    //console.log(connected?"connected":"disConnected");
}

function connect(fileName) {
    var socket = new SockJS(host+'/myUrl' + '?token='+fileName);
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function(frame) {
        setConnected(true);
        //console.log('Connected:' + frame);
        stompClient.subscribe('/user/queue/sendUser', function(response) {
			//alert(1);
            showResponse(response.body);
        });
    });
}
function disconnect() {
    if (stompClient != null) {
        stompClient.disconnect();
    }
    setConnected(false);
}
function send(referFile, data, isValued) {
	//stompClient.send("/sendToWorkbook", {}, JSON.stringify({isValued:isValued, message:message}));
	data.isValued = isValued;
	stompClient.send("/sendToWorkbook", {}, JSON.stringify({referFile: referFile, data: JSON.stringify(data) }));
}
function showResponse(response) {
	console.log(response);
	
	if(!response){
		console.log("收到Websocket空信息");
		return;
	}
	var asyncDatas = JSON.parse(response);
	
	var spread = GC.Spread.Sheets.findControl('ss');
	spread.suspendCalcService(true);
	spread.suspendPaint();
	
	if(asyncDatas.isValued){
		asyncDatas.formulas.forEach(function(d){
			var sheet = spread.getSheetFromName(d.sheetName);
			var formula = sheet.getFormula(d.row, d.col);
			sheet.setTag(d.row, d.col, {formula: formula});
			sheet.setFormula(d.row, d.col, null);
			sheet.setValue(d.row, d.col, d.value);
		});
		var flg = true;
		relations.forEach(function(r){
			r.referFile == asyncDatas.referFile? flg=!flg: flg;
		});
		flg? relations.push(asyncDatas):false;
	}else{
		var formulas = asyncDatas.formulas;
		formulas.forEach(function(f){
			var formula = f.formula;
			var sheetName = formula.split("!")[0];
			sheetName = sheetName.substring(sheetName.indexOf("]")+1);
			var sheet = spread.getSheetFromName(sheetName);
			if(sheet){
				var range = GC.Spread.Sheets.CalcEngine.formulaToRanges(sheet, formula, 0, 0)[0].ranges[0];
				f.value = sheet.getValue(range.row, range.col);
			}
			console.log(f);
		});
		send(asyncDatas.loadedFile, asyncDatas, true);
	}
	spread.resumePaint();
	spread.resumeCalcService(false);
	
}

/*****************WebSocket End*********************/


function importData(fileName){
    var excelIo = new GC.Spread.Excel.IO();
    // Download Excel file
    //var excelFilePath = 'resources/Excel/importExcel.xlsx';
    var xhr = new XMLHttpRequest();
    xhr.open('GET', "loader/downLoad?fileName="+fileName, true);
    xhr.responseType = 'blob';
    xhr.onload = function() {
      if (this.status == 200) {
        // get binary data as a response
        var blob = this.response;
        // convert Excel to JSON
        excelIo.open(blob, function (json) {
            var workbookObj = json;
            GC.Spread.Sheets.findControl('ss').fromJSON(workbookObj);
			formulaCache = [];
			loadedFile = fileName;
			/** 
				加载后立即连接WebSocket
			*/
			disconnect();
			connect(fileName);
			
		    $("#loadWorkbookList").modal('hide')
        }, function (e) {
            // process error
            alert(e.errorMessage);
        }, {});
      }
    };
    xhr.send();
}

// T 同步所有数据（刷新）
function asynAllData(){
	relations.forEach(function(d){
		send(d.referFile, d, false);
	});
}

//D 建立连接
function getRelations(){
	var datas = [];
	$(".links").each(function(){
		var refer = $(this).attr('data-refer');
		var referFile = $(this).find('select').val();
		
		datas.push({
			loadedFile: loadedFile,
			refer: refer,
			referFile: referFile
		});
	});
	
	formulaCache.forEach(function(f){
		datas.forEach(function(d){
			if(f.refer == d.refer){
				d.formulas = f.formulas;
			}
		});
	});
	datas.forEach(function(d){
		
		send(d.referFile, d, false);
	});
	//console.log(datas);
	//send(datas, false);
	
	
	$("#workbookRelateList").modal('hide')
}

// Analyze the association
function association(){
	var spread = GC.Spread.Sheets.findControl('ss');
	analyzeRefers (spread)
	if(formulaCache.length == 0){
		alert("没有发现跨Workbook引用！");
		return;
	}
	formulaCache.forEach(function(item){
		createRelateList(item);
	});
	
	$("#workbookRelateList").modal('show')
}

	//T 创建列表
	function createRelateList(item){
		var refer = item.refer;
		var tr = '<tr class="links" data-refer="[x]"></tr>';
		var th = '<th scope="row">[x]</th>';
		var workbookTd = '<td><select class="selectpicker" id="referWorkbook'+
			'[x]"><option selected value="子表1.xlsx">子表1.xlsx</option>'+
			'<option value="子表2.xlsx">子表2.xlsx</option>'+
			'<option value="子表3.xlsx">子表3.xlsx</option>'+
			'<option value="子表4.xlsx">子表4.xlsx</option>'+
			'<option value="汇总表.xlsx">汇总表.xlsx</option></select></td>';
		var trDom = $(tr.replace("[x]", refer));
		trDom.append(th.replace("[x]", "["+refer+"]"));
		trDom.append(workbookTd.replace("[x]", "["+refer+"]"));
		$("#relateList").append(trDom);
	}
	
	//T 解析引用关系
	function analyzeRefers (spread){
		spread.sheets.forEach(function(sheet){
			var colCount = sheet.getColumnCount();
			var rowCount = sheet.getRowCount();
			var sheetName = sheet.name();
			for(let i=0; i<rowCount; i++){
				for(let j=0; j<colCount; j++){
					var formula = sheet.getFormula(i,j);
					var tag = sheet.getTag(i,j);
					if(formula || !formula && tag && tag.formula){
						//Analyze cross workbook reference
						var results = getExecStrs(formula || tag.formula);
						if(results && results.length>0){
							getRefer(results, sheetName, formula || tag.formula, i, j);
						}
					}
				}
			}
		});
	}
		
		//T2	获取引用关系
		function getRefer (results, sheetName, formula, row, col){
			results.forEach(function(item){
				var index = getReferIndex(item);
				var formulas = null;
				index == -1? formulaCache.push({ refer: item , formulas : formulas=[]}) : 
					formulas = formulaCache[index].formulas;
				formulas.push({sheetName: sheetName, row: row, col: col, formula: formula});
			});
		}
		
		//T2	获取引用关系Index
		function getReferIndex (refer){
			var index = -1;
			formulaCache.forEach(function(ws, i){
				if(ws.refer == refer){
					index = i;
				}
			})
			return index;
		}
		
		//T2	解析[1]
		function getExecStrs (str) {
		    var reg = /\[(.+?)\]/g
		    //var reg = /\$\{(.+?)\}/g
		    var list = []
		    var result = null
		    do {
		        result = reg.exec(str)
		        result && list.push(result[1])
		    } while (result)
		    return list
		}
